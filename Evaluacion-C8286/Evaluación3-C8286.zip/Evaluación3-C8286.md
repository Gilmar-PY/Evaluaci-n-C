﻿1\. Crear un Bash Script simple

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.001.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.002.png)

proceso

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.003.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.004.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.005.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.006.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.007.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.008.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.009.png)

2\.-Crear una aplicación web simple

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.010.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.011.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.012.png)

3\.-Configurar la aplicación web para utilizar archivos de sitio web

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.013.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.014.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.015.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.016.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.017.png)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.018.png)

4\.-Crear un script de Bash para compilar y ejecutar un contenedor Docker

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.019.jpeg)

![](Aspose.Words.8c691c8d-b32e-4f2e-8895-99b2471049af.020.jpeg)

5\.-Crear, ejecutar y verificar el contenedor Docker
