import threading
import random
import time

class Robot:
    def __init__(self, id, total_robots):
        self.id = id
        self.state = f"Idle"
        self.total_robots = total_robots
        self.channels = {i: [] for i in range(total_robots) if i != id}
        self.snapshots = []

    def set_state(self, state):
        self.state = state

    def send_message(self, receiver, message):
        self.channels[receiver].append(message)

    def take_snapshot(self):
        snapshot = {"id": self.id, "state": self.state, "channels": self.channels.copy()}
        self.snapshots.append(snapshot)
        print(f"Robot {self.id} took a snapshot: {snapshot}")

    def execute_task(self):
        for _ in range(3):  # Each robot executes 3 tasks
            task = random.choice(["Welding", "Assembling", "Painting"])
            self.set_state(task)
            print(f"Robot {self.id} is executing task: {task}")
            time.sleep(random.uniform(0.5, 1.5))  # Simulate task duration

            # Send a message to another robot randomly
            receiver = random.choice([i for i in range(self.total_robots) if i != self.id])
            message = f"Task {task} completed"
            self.send_message(receiver, message)
            print(f"Robot {self.id} sent message to Robot {receiver}: {message}")

            # Randomly decide to take a snapshot
            if random.choice([True, False]):
                self.take_snapshot()

    def start(self):
        thread = threading.Thread(target=self.execute_task)
        thread.start()
        return thread

def main():
    total_robots = 3
    robots = [Robot(id, total_robots) for id in range(total_robots)]

    # Start all robots
    threads = [robot.start() for robot in robots]

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()
