Pregunta 1
La salida del algoritmopara que simule cómo los Jupyter Notebooks manejan eventos e interacciones de usuario
INFO:__main__:Ejecutando celda: Celda 2
INFO:__main__:Celda Celda 2 ejecutada con éxito
INFO:__main__:Ejecutando celda: Celda 1
INFO:__main__:Celda Celda 1 ejecutada con éxito
INFO:__main__:Ejecutando celda: Celda 3
INFO:__main__:Celda Celda 3 ejecutada con éxito

Este código algoritmo simula de cómo los Jupyter Notebooks manejan eventos e interacciones de usuario a medida que los usuarios
interactuan con Jupytes







Pregunta 2

La salida para del código utilizando el algoritmo Chandy Lamport para sistema de coordinacion de tareas en una red de
robot industriales es:
Robot 0 is executing task: Painting
Robot 1 is executing task: Assembling
Robot 2 is executing task: Welding
Robot 2 sent message to Robot 1: Task Welding completed
Robot 2 is executing task: Assembling
Robot 0 sent message to Robot 1: Task Painting completed
Robot 0 is executing task: Painting
Robot 0 sent message to Robot 2: Task Painting completed
Robot 0 is executing task: Welding
Robot 1 sent message to Robot 0: Task Assembling completed
Robot 1 is executing task: Welding
Robot 2 sent message to Robot 1: Task Assembling completed
Robot 2 is executing task: Painting
Robot 0 sent message to Robot 1: Task Welding completed
Robot 0 took a snapshot: {'id': 0, 'state': 'Welding', 'channels': {1: ['Task Painting completed', 'Task Welding completed'], 2: ['Task Painting completed']}}
Robot 1 sent message to Robot 2: Task Welding completed
Robot 1 is executing task: Painting
Robot 2 sent message to Robot 0: Task Painting completed
Robot 2 took a snapshot: {'id': 2, 'state': 'Painting', 'channels': {0: ['Task Painting completed'], 1: ['Task Welding completed', 'Task Assembling completed']}}
Robot 1 sent message to Robot 2: Task Painting completed
Robot 1 took a snapshot: {'id': 1, 'state': 'Painting', 'channels': {0: ['Task Assembling completed'], 2: ['Task Welding completed', 'Task Painting completed']}}

En un sistema real el algoritmo requiere de que un robot arranque o inicie la toma de instanataneas enviando un mensaje marcador
en este caso es marker a todos los demás robots, para que despues registren sus estados
y los mensajes recibidos después del marcador

Respuesta 4

Node 1 has failed.
Node 2 has healed.
Node 0 has failed.
Node 2 has healed.
Node 1 has failed.
Node 0 has healed.
Node 1 has failed.
Node 1 has healed.
Node 1 has failed.
Node 4 has healed

Esto algoritmo simula la fallla en una nodo determinado, es decir si hay una falla en el Nodo 2, por el output
indica la falla, así como se puede ver en la salida de la ejecucíon del algoritmo simulado
